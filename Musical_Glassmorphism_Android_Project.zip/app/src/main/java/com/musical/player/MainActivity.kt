package com.musical.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

data class Song(val title: String, val artist: String, val uri: Uri)

private val Mint = Color(0xFF7CF7D4)
private val Sky = Color(0xFF86B9FF)
private val Ink = Color(0xFF0B1020)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var equalizer: Equalizer? = null

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({ controller = controllerFuture?.get() }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MusicalApp(
                loadSongs = { readSongs() },
                playSong = { index, songs ->
                    controller?.apply {
                        setMediaItems(songs.map { MediaItem.fromUri(it.uri) }, index, 0L)
                        prepare()
                        play()
                    }
                },
                player = { controller },
                openEqualizer = { enableEqualizer() }
            )
        }
    }

    private fun readSongs(): List<Song> {
        val result = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (c.moveToNext()) {
                result += Song(c.getString(title) ?: "Unknown track",
                    c.getString(artist) ?: "Unknown artist",
                    Uri.withAppendedPath(collection, c.getLong(id).toString()))
            }
        }
        return result
    }

    private fun enableEqualizer() {
        try {
            val id = controller?.audioSessionId ?: return
            equalizer?.release()
            equalizer = Equalizer(0, id).apply { enabled = true }
        } catch (_: Exception) { }
    }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.background(
            Brush.linearGradient(listOf(Color(0x553A547A), Color(0x332A3555), Color(0x223F7C83))),
            RoundedCornerShape(22.dp)
        ).border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(22.dp)).padding(14.dp),
        content = content
    )
}

@Composable
fun MusicalApp(
    loadSongs: () -> List<Song>,
    playSong: (Int, List<Song>) -> Unit,
    player: () -> MediaController?,
    openEqualizer: () -> Unit
) {
    var songs by remember { mutableStateOf(emptyList<Song>()) }
    var tab by remember { mutableStateOf("Discover") }
    var lightTheme by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var playlist by remember { mutableStateOf(listOf<Song>()) }
    var lyrics by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) songs = loadSongs()
    }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) songs = loadSongs()
        else launcher.launch(permission)
    }

    val background = if (lightTheme) Color(0xFFE8F0FA) else Ink
    val foreground = if (lightTheme) Color(0xFF14213A) else Color(0xFFF4F7FF)
    val muted = if (lightTheme) Color(0xFF60718B) else Color(0xFFAAB6CC)
    val filtered = songs.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
    val current = player()

    MaterialTheme(colorScheme = if (lightTheme) lightColorScheme(primary = Color(0xFF168D83), background = background)
        else darkColorScheme(primary = Mint, background = background, surface = Color(0xFF18233A))) {
        Scaffold(
            containerColor = background,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF111A2B), contentColor = Color.White) {
                    listOf("Discover", "Library", "Playlists", "Lyrics").forEach { name ->
                        NavigationBarItem(
                            selected = tab == name,
                            onClick = { tab = name },
                            icon = { Icon(when (name) {
                                "Discover" -> Icons.Default.Explore
                                "Library" -> Icons.Default.LibraryMusic
                                "Playlists" -> Icons.Default.QueueMusic
                                else -> Icons.Default.Lyrics
                            }, null) },
                            label = { Text(name) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Mint, selectedTextColor = Mint,
                                indicatorColor = Color(0xFF263A50), unselectedIconColor = Color.LightGray,
                                unselectedTextColor = Color.LightGray)
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF182B48), background, Color(0xFF101A2D)))
            ).padding(padding)) {
                Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("M U S I C A L", color = Mint, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text(tab, color = foreground, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { lightTheme = !lightTheme }) {
                            Icon(if (lightTheme) Icons.Default.DarkMode else Icons.Default.LightMode, "Switch theme", tint = foreground)
                        }
                    }

                    when (tab) {
                        "Discover", "Library" -> {
                            GlassPanel(Modifier.fillMaxWidth().padding(top = 14.dp)) {
                                Text("Your sound, your space.", color = foreground, fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleLarge)
                                Text("Play music stored on your phone — no internet needed.", color = muted,
                                    style = MaterialTheme.typography.bodySmall)
                                OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(top = 12.dp),
                                    placeholder = { Text("Search tracks") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                                    singleLine = true)
                            }
                            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("ON THIS DEVICE  ·  ${songs.size} TRACKS", color = muted, style = MaterialTheme.typography.labelMedium)
                                TextButton(onClick = { songs = loadSongs() }) { Text("Refresh", color = Mint) }
                            }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                itemsIndexed(filtered) { _, song ->
                                    Row(Modifier.fillMaxWidth().background(Color(0x332F4966), RoundedCornerShape(16.dp))
                                        .border(1.dp, Color(0x223FFFFFF), RoundedCornerShape(16.dp))
                                        .clickable { playSong(songs.indexOf(song), songs) }.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(46.dp).background(
                                            Brush.linearGradient(listOf(Color(0xFF276B70), Color(0xFF4C4A86))),
                                            RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.MusicNote, null, tint = Mint)
                                        }
                                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                            Text(song.title, color = foreground, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                            Text(song.artist, color = muted, style = MaterialTheme.typography.bodySmall)
                                        }
                                        IconButton(onClick = { playlist = playlist + song }) {
                                            Icon(Icons.Default.AddCircleOutline, "Add to playlist", tint = Mint)
                                        }
                                    }
                                }
                            }
                        }
                        "Playlists" -> {
                            GlassPanel(Modifier.fillMaxWidth().padding(top = 20.dp)) {
                                Text("My playlist", color = foreground, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                                Text("Add tracks from your library using the + button.", color = muted)
                            }
                            LazyColumn {
                                itemsIndexed(playlist) { index, song ->
                                    ListItem(headlineContent = { Text(song.title, color = foreground) },
                                        supportingContent = { Text(song.artist, color = muted) },
                                        leadingContent = { Icon(Icons.Default.MusicNote, null, tint = Mint) },
                                        modifier = Modifier.clickable { playSong(songs.indexOf(song).coerceAtLeast(0), songs) },
                                        colors = ListItemDefaults.colors(containerColor = Color.Transparent))
                                }
                            }
                        }
                        "Lyrics" -> {
                            GlassPanel(Modifier.fillMaxWidth().padding(top = 20.dp)) {
                                Text("Lyrics studio", color = foreground, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                                Text("Keep lyrics or notes for a track here.", color = muted)
                                OutlinedTextField(lyrics, { lyrics = it }, Modifier.fillMaxWidth().padding(top = 12.dp),
                                    minLines = 8, label = { Text("Paste or write lyrics") })
                                Text("Lyrics are entered manually; automatic lyric lookup is not included.", color = muted,
                                    style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    GlassPanel(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Mint, Sky)), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.GraphicEq, null, tint = Ink)
                            }
                            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                                Text(current?.mediaMetadata?.title?.toString() ?: "Nothing playing",
                                    color = foreground, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(current?.mediaMetadata?.artist?.toString() ?: "Choose a track",
                                    color = muted, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { current?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, null, tint = foreground) }
                            IconButton(onClick = { if (current?.isPlaying == true) current.pause() else current?.play() }) {
                                Icon(if (current?.isPlaying == true) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                                    "Play or pause", tint = Mint, modifier = Modifier.size(34.dp))
                            }
                            IconButton(onClick = { current?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, tint = foreground) }
                        }
                    }
                    TextButton(onClick = openEqualizer, modifier = Modifier.align(Alignment.End)) {
                        Icon(Icons.Default.Equalizer, null, tint = Mint); Text("  Equalizer", color = Mint)
                    }
                }
            }
        }
    }
}
