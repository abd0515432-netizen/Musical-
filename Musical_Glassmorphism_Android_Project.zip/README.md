# Musical — Android music player

A Spotify-inspired, offline-first native Android starter project.

## Included
- Reads local audio from Android MediaStore (permission required)
- Playback queue using AndroidX Media3 / ExoPlayer
- MediaSessionService for background playback and system media controls
- Search, simple in-memory playlist, lyrics text editor
- Dark/light theme toggle
- Android Equalizer effect hook

## Build an APK
1. Install Android Studio (Hedgehog or newer) and Android SDK 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install any requested SDK components.
4. Connect an Android phone or use an emulator.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
This is a starter implementation, not a fully polished store release. Playlist and lyric edits are currently in-memory and reset when the app process is closed. Lyrics are manually entered; automatic lyric search is not included. Equalizer availability depends on the device audio effects implementation. Background playback uses Media3's media session service.
